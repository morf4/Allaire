//******************** LOCALIZABLE GLOBALS VARS *****************************
// due to some strange bug in javascript, because this file is included and not
// used directly, the strings need to be placed in the functions that use them
// to change, edit the stings in checkElementEntry() and 


//**************************GLOBAL VARS *************************************
var layerInfo;
var elementInfo
var currentLayerName;
var allLayerGroups;

//************************ OBJECT FUNCTIONS ********************************
function findObject(objName,  parentObj) {
  var i,tempObj="",found=false,curObj = "";
  var NS = (navigator.appName.indexOf("Netscape") != -1);
  if (!NS && document.all) curObj = document.all[objName]; //IE4
  else {
    parentObj = (parentObj != null)? parentObj.document : document;
    if (parentObj[objName] != null) curObj = parentObj[objName]; //at top level
    else { //if in form
      if (parentObj.forms) for (i=0; i<parentObj.forms.length; i++) {  //search level for form object
        if (parentObj.forms[i][objName]) {
          curObj = parentObj.forms[i][objName];
          found = true; break;
      } }
      if (!found && NS && parentObj.layers && parentObj.layers.length > 0) {
        parentObj = parentObj.layers;
        for (i=0; i<parentObj.length; i++) { //else search for child layers
          tempObj = findObject(objName,parentObj[i]); //recurse
          if (tempObj) { curObj = tempObj; break;} //if found, done
  } } } }
  return curObj;
}

//Emulates printf("blah blah %s blah %s",str1,str2)
//Used for concatenating error message for easier localization.
//Returns assembled string.
function errMsg() {
  var i,numArgs,errStr="",argNum=0,startPos;

  numArgs = errMsg.arguments.length;
  if (numArgs) {
    theStr = errMsg.arguments[argNum++];
    startPos = 0;  endPos = theStr.indexOf("%s",startPos);
    if (endPos == -1) endPos = theStr.length;
    while (startPos < theStr.length) {
      errStr += theStr.substring(startPos,endPos);
      if (argNum < numArgs) errStr += errMsg.arguments[argNum++];
      startPos = endPos+2;  endPos = theStr.indexOf("%s",startPos);
      if (endPos == -1) endPos = theStr.length;
    }
    if (!errStr) errStr = errMsg.arguments[0];
  }
  return errStr;
}

// set a field with a browse dialog. It better be text!
function browseElement(elementName) {
	var object = findObject(elementName)
	object.value = browseForFileURL();
}


// the Info object puts or gets parameter values to and from
// their saved or default values
function createLayerInfo(layerName, element, parName, parDefault, parType, parLowLimit, parHiLimit) {
	if (layerInfo == null)
		layerInfo = new Object();

	if (elementInfo == null)
		elementInfo = new Object();

	// create the element list for this layer
	var infoList = new Object();

	// create the info for all the element, and add element name to the layers element list 
	var i=1;
	while (i < arguments.length) {
		var info = new Object();
		var elementName = arguments[i++];	//element of layer to get/set
		info.object = findObject(elementName);

		info.parName = arguments[i++];	// parameter of element to get/set
		info.parType = arguments[i++]; // what type of parameter is it

		info.def = arguments[i++];	//default value
		info.saved = info.def;	//saved value originally set default
		info.object[info.parType] = info.def; // assign default value

		// get the range if appropriate
		if (info.parType == "integer range" || info.parType == "real range") { // add limits
			info.lowLimit = arguments[i++];
			info.highLimit = arguments[i++];
		} else if (info.parType == "select") // if the object is a selection, get a list of their values
			info.selectName = arguments[i++];

		elementInfo[elementName] = info;
		infoList[elementName] = info;
	}

	layerInfo[layerName] = infoList;// add to array of layer info
}

function setLayerGroup(mainLayer, layerDepend1) {
	if (allLayerGroups == null)
		allLayerGroups = new Object();

	var groupList = new Array(arguments.length-1);
	for (var i = 1; i<arguments.length; i++) 
 		groupList[i-1] = arguments[i];

	allLayerGroups[mainLayer]= groupList;
}

// reset all layer info
function destroyAllLayerInfo() {
	hideAllLayers();	
	layerInfo = null;
	elementInfo = null;
	currentLayerName = null;
	allLayerGroups = null;
}

function isReal(value) {
	return (value == (value*1));
}

function isInteger(value) {
	return (value == Math.floor(value));
}

function isWhole(value) {
	return (isInteger(value) && value>=0);
}

function checkElementEntry(elementName) {
	// localizable
	var MSG_BAD_NUMBER = "Please enter a number.";
	var MSG_BAD_INTEGER = "Please enter an integer.";
	var MSG_BAD_WHOLE = "Please enter an integer 0 or greater.";
	var MSG_BAD_INTEGER_RANGE = "Please enter a number between %s and %s.";
	var MSG_BAD_REAL_RANGE = "Please enter an integer between %s and %s.";
	
	var info = elementInfo[elementName];
	var value = info.object[info.parName];
	var alertStr = "";

	switch (info.parType) {
	case "real":
		if (!isReal(value))
			alertStr = MSG_BAD_NUMBER;
		break;

	case "integer":
		if (!isInteger(value)) 
			alertStr = MSG_BAD_INTEGER;
		break;

	case "whole":
		if (!isWhole(value)) 
			alertStr = MSG_BAD_WHOLE;
		break;

	case "real range": 
		if (!isReal(value) || value < info.lowLimit || value > info.highLimit) 
			alertStr = errMsg(MSG_BAD_REAL_RANGE,info.lowLimit,info.highLimit);
		break;

	case "integer range": 
		if (!isInteger(value) || value < info.lowLimit || value > info.highLimit) 
			alertStr = errMsg(MSG_BAD_INTEGER_RANGE,info.lowLimit,info.highLimit);
		break;
	}

	if (alertStr != "") {
		alert(alertStr);
		//info.object[info.parName] = info.def;
		info.object.focus();
		return false;
	}

	return true;
}

// checks for any missing layers and displays a warning listing them
function checkForMissingElements() {
	// localizable
	var MSG_MISSING = "Missing: %s.\nObject needs to be edited to function properly.";
	
	var missingList = "";
	for (var i=0; i<arguments.length; i++) {
		info = elementInfo[arguments[i++]];
		if (info.saved == "") {
			missingList = missingList + arguments[i] + ", ";
	}	}
	
	if (missingList != "") {
		alert(errMsg(MSG_MISSING, missingList.substring(0,missingList.length-2)));
		return false;
	} else
		return true;
}

// recalls the info from either default or saved, setting all the parameters
// in the argument list to their corresponding default or saved value
function recallLayerInfo(layerName, fromWhat) {
	var infoList = layerInfo[layerName];
	for (var elementName in infoList) {
		var info = infoList[elementName];
		info.object[info.parName] = info[fromWhat];
		//alert(layerName+"["+elementName+"]."+info.parName+"="+fromWhat+"="+info[fromWhat]);
}	}


// puts the info from all the parameters in the argument list to their 
// corresponding default or saved value
function storeLayerInfo(layerName, toWhat) {
	var infoList = layerInfo[layerName];
	for (var elementName in infoList) {
		var info = infoList[elementName];
		info[toWhat] = info.object[info.parName];
		//alert(toWhat+"="+layerName+"["+elementName+"]."+info.parName+"="+info.object[info.parName]);
}	}

// returns asociative array of an elements parameter
function getElementInfo(elementName, fromWhat) {
	if (fromWhat == "selectedIndexName") // return name of selected index for a select
		return elementInfo[elementName].selectName[elementInfo[elementName].object.selectedIndex];

	else
		return elementInfo[elementName][fromWhat];
}

// sets the element info
function setElementInfo(elementName, toWhat, value) {
	elementInfo[elementName][toWhat] = value;
}

// reset all the form values. Called at OnLoad and after tag string built
function recallAllLayerInfo(fromWhat, visibility) {
	for (var layerName in layerInfo) {
		if (visibility == null || findObject(layerName).visibility == visibility)
			recallLayerInfo(layerName,fromWhat);
}	}

// store all shown layers to saved state
function storeAllLayerInfo(toWhat, visibility) {
	for (var layerName in layerInfo) {
		if (visibility == null || findObject(layerName).visibility == visibility) 
			storeLayerInfo(layerName,toWhat);
}	}	

// returns asociative array of an elements parameter
function getAllElementInfo(fromWhat) {
	allInfo = new Object();
	for (var elementName in elementInfo) 
		allInfo[elementName] = elementInfo[elementName][fromWhat];
	return allInfo;
}

function showLayer(layerName) {
	findObject(layerName).visibility = "visible";
	recallLayerInfo(layerName, "saved");
}

function hideLayer(layerName) {
	storeLayerInfo(layerName, "saved");
	findObject(layerName).visibility = "hidden";
}

function hideAllLayers() {
	for (layerName in layerInfo) 
		hideLayer(layerName);
}

// switch from one layer to the other, keeping the info
function switchToLayer(newLayerName) {
	if (currentLayerName != null) { // hide old layer if there is one
		if (allLayerGroups != null) {
			groupList = allLayerGroups[currentLayerName];
			if (groupList != null) // hide all layers in the group
				for (var i = 0; i<groupList.length; i++) 
					hideLayer(groupList[i]); 
		}
		 
		hideLayer(currentLayerName); // hide the current layer
	}

	currentLayerName = newLayerName; 
	if (currentLayerName != null) { // show the new layer if it exists
		if (allLayerGroups != null) {
			layerGroup = allLayerGroups[currentLayerName];
			if (layerGroup != null) // show all layers in the group
				for (var i = 0; i<layerGroup.length; i++) 
					showLayer(layerGroup[i]); 
		}
		 
		showLayer(currentLayerName); // show the current layer
}	}