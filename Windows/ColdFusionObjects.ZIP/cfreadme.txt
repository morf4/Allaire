Thank you for downloading the Cold Fusion objects for Dreamweaver!

Here's some information to get you started using them:


Installation
=============
Drag the folder called CFML into the Configuration/Objects/ folder inside the 
Dreamweaver application folder. If you would like to add the objects to a submenu 
on the Insert Menu, you will need to open the InsertMenuAdditionCF.htm and 
copy the html there and paste it into the InsertMenu.htm in the Configuration/Objects/ 
folder. 

Before you edit the InsertMenu.htm file, be sure you save a copy of it so 
that your changes are not lost. 


Inserting Cold Fusion objects
=============================
To insert Cold Fusion objects, do one of the following:

- Choose Insert > Cold Fusion Object and select the desired
  object from the list.
  
- Select Cold Fusion from the pop-up menu at the top of the 
  Object palette, and click a button to insert the desired
  object.
  
If you have the Show Dialog when Inserting Objects option turned on in your General
Preferences (Edit > Preferences > General), a dialog box appears to let you specify 
parameters for the object. If you have this option turned off, the object is inserted
with undefined parameters. You will need to edit the tag manually in the HTML inspector
to assign attribute values.


Editing Cold Fusion tags
========================
There are currently no Property inspectors available for any of the Cold Fusion objects.
To edit CFML tag attributes or attribute values, choose Window > HTML to open HTML inspector
and makes changes to the tag. You can edit content between CFML tags directly in the Document
window.

Only the CFQUERY tag and tags that surround content (such as CFMAIL and CFOUTPUT) have 
visual representations in the Document window. To see markers for CFQUERY tags, 
choose View > Invisible Elements, and make sure that the Scripts option is turned on 
in the Invisible Elements Preferences (Edit > Preferences > Invisible Elements).
